﻿
namespace pr4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddDisk = new System.Windows.Forms.Button();
            this.btnRemoveDisk = new System.Windows.Forms.Button();
            this.btnAddSong = new System.Windows.Forms.Button();
            this.btnRemoveSong = new System.Windows.Forms.Button();
            this.lstDisks = new System.Windows.Forms.ListBox();
            this.lstResults = new System.Windows.Forms.ListBox();
            this.btnViewCatalog = new System.Windows.Forms.Button();
            this.btnViewDisk = new System.Windows.Forms.Button();
            this.btnSearchArtist = new System.Windows.Forms.Button();
            this.txtArtist = new System.Windows.Forms.TextBox();
            this.txtDiskName = new System.Windows.Forms.TextBox();
            this.txtSongInfo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnAddDisk
            // 
            this.btnAddDisk.AutoSize = true;
            this.btnAddDisk.Location = new System.Drawing.Point(57, 279);
            this.btnAddDisk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddDisk.Name = "btnAddDisk";
            this.btnAddDisk.Size = new System.Drawing.Size(125, 28);
            this.btnAddDisk.TabIndex = 0;
            this.btnAddDisk.Text = "Добавить диск";
            this.btnAddDisk.UseVisualStyleBackColor = true;
            this.btnAddDisk.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRemoveDisk
            // 
            this.btnRemoveDisk.AutoSize = true;
            this.btnRemoveDisk.Location = new System.Drawing.Point(57, 331);
            this.btnRemoveDisk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveDisk.Name = "btnRemoveDisk";
            this.btnRemoveDisk.Size = new System.Drawing.Size(116, 28);
            this.btnRemoveDisk.TabIndex = 1;
            this.btnRemoveDisk.Text = "Удалить диск";
            this.btnRemoveDisk.UseVisualStyleBackColor = true;
            this.btnRemoveDisk.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnAddSong
            // 
            this.btnAddSong.AutoSize = true;
            this.btnAddSong.Location = new System.Drawing.Point(796, 276);
            this.btnAddSong.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddSong.Name = "btnAddSong";
            this.btnAddSong.Size = new System.Drawing.Size(136, 28);
            this.btnAddSong.TabIndex = 2;
            this.btnAddSong.Text = "Добавить песню";
            this.btnAddSong.UseVisualStyleBackColor = true;
            this.btnAddSong.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnRemoveSong
            // 
            this.btnRemoveSong.AutoSize = true;
            this.btnRemoveSong.Location = new System.Drawing.Point(805, 331);
            this.btnRemoveSong.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveSong.Name = "btnRemoveSong";
            this.btnRemoveSong.Size = new System.Drawing.Size(127, 28);
            this.btnRemoveSong.TabIndex = 3;
            this.btnRemoveSong.Text = "Удалить песню";
            this.btnRemoveSong.UseVisualStyleBackColor = true;
            this.btnRemoveSong.Click += new System.EventHandler(this.button4_Click);
            // 
            // lstDisks
            // 
            this.lstDisks.FormattingEnabled = true;
            this.lstDisks.ItemHeight = 16;
            this.lstDisks.Location = new System.Drawing.Point(57, 36);
            this.lstDisks.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lstDisks.Name = "lstDisks";
            this.lstDisks.Size = new System.Drawing.Size(404, 212);
            this.lstDisks.TabIndex = 4;
            // 
            // lstResults
            // 
            this.lstResults.FormattingEnabled = true;
            this.lstResults.ItemHeight = 16;
            this.lstResults.Location = new System.Drawing.Point(527, 36);
            this.lstResults.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lstResults.Name = "lstResults";
            this.lstResults.Size = new System.Drawing.Size(404, 212);
            this.lstResults.TabIndex = 5;
            // 
            // btnViewCatalog
            // 
            this.btnViewCatalog.AutoSize = true;
            this.btnViewCatalog.Location = new System.Drawing.Point(412, 276);
            this.btnViewCatalog.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnViewCatalog.Name = "btnViewCatalog";
            this.btnViewCatalog.Size = new System.Drawing.Size(184, 28);
            this.btnViewCatalog.TabIndex = 6;
            this.btnViewCatalog.Text = "Посмотреть весь каталог";
            this.btnViewCatalog.UseVisualStyleBackColor = true;
            this.btnViewCatalog.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnViewDisk
            // 
            this.btnViewDisk.AutoSize = true;
            this.btnViewDisk.Location = new System.Drawing.Point(412, 331);
            this.btnViewDisk.Margin = new System.Windows.Forms.Padding(4);
            this.btnViewDisk.Name = "btnViewDisk";
            this.btnViewDisk.Size = new System.Drawing.Size(221, 28);
            this.btnViewDisk.TabIndex = 7;
            this.btnViewDisk.Text = "Посмотреть содержимое диска";
            this.btnViewDisk.UseVisualStyleBackColor = true;
            this.btnViewDisk.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnSearchArtist
            // 
            this.btnSearchArtist.AutoSize = true;
            this.btnSearchArtist.Location = new System.Drawing.Point(57, 474);
            this.btnSearchArtist.Margin = new System.Windows.Forms.Padding(4);
            this.btnSearchArtist.Name = "btnSearchArtist";
            this.btnSearchArtist.Size = new System.Drawing.Size(221, 28);
            this.btnSearchArtist.TabIndex = 8;
            this.btnSearchArtist.Text = "Найти песню по исполнителю";
            this.btnSearchArtist.UseVisualStyleBackColor = true;
            this.btnSearchArtist.Click += new System.EventHandler(this.button7_Click);
            // 
            // txtArtist
            // 
            this.txtArtist.Location = new System.Drawing.Point(57, 432);
            this.txtArtist.Name = "txtArtist";
            this.txtArtist.Size = new System.Drawing.Size(221, 22);
            this.txtArtist.TabIndex = 9;
            // 
            // txtDiskName
            // 
            this.txtDiskName.Location = new System.Drawing.Point(215, 282);
            this.txtDiskName.Name = "txtDiskName";
            this.txtDiskName.Size = new System.Drawing.Size(143, 22);
            this.txtDiskName.TabIndex = 11;
            // 
            // txtSongInfo
            // 
            this.txtSongInfo.Location = new System.Drawing.Point(646, 279);
            this.txtSongInfo.Name = "txtSongInfo";
            this.txtSongInfo.Size = new System.Drawing.Size(143, 22);
            this.txtSongInfo.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.txtSongInfo);
            this.Controls.Add(this.txtDiskName);
            this.Controls.Add(this.txtArtist);
            this.Controls.Add(this.btnSearchArtist);
            this.Controls.Add(this.btnViewDisk);
            this.Controls.Add(this.btnViewCatalog);
            this.Controls.Add(this.lstResults);
            this.Controls.Add(this.lstDisks);
            this.Controls.Add(this.btnRemoveSong);
            this.Controls.Add(this.btnAddSong);
            this.Controls.Add(this.btnRemoveDisk);
            this.Controls.Add(this.btnAddDisk);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddDisk;
        private System.Windows.Forms.Button btnRemoveDisk;
        private System.Windows.Forms.Button btnAddSong;
        private System.Windows.Forms.Button btnRemoveSong;
        private System.Windows.Forms.ListBox lstDisks;
        private System.Windows.Forms.ListBox lstResults;
        private System.Windows.Forms.Button btnViewCatalog;
        private System.Windows.Forms.Button btnViewDisk;
        private System.Windows.Forms.Button btnSearchArtist;
        private System.Windows.Forms.TextBox txtArtist;
        private System.Windows.Forms.TextBox txtDiskName;
        private System.Windows.Forms.TextBox txtSongInfo;
    }
}

