﻿using pr4;
using System;
using System.Windows.Forms;

namespace MusicCatalogApp
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Настройка основных параметров приложения
            Application.EnableVisualStyles(); // Включает визуальные стили операционной системы
            Application.SetCompatibleTextRenderingDefault(false); // Отключает устаревший режим отрисовки текста

            // Запуск главной формы приложения
            Application.Run(new Form1());
        }
    }
}